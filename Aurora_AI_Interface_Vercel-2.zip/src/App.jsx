import React, { useMemo, useState } from "react";
import {
  Menu, Plus, Search, MessageSquare, Settings, Sparkles, Paperclip,
  Mic, Send, ChevronDown, PanelLeftClose, Copy, ThumbsUp, ThumbsDown,
  RotateCcw, MoreHorizontal, Bot, User, X
} from "lucide-react";

const starterPrompts = [
  ["✦", "Help me plan a research project"],
  ["◈", "Analyze this business idea"],
  ["⌁", "Create a professional report"],
  ["✧", "Build a field operations plan"]
];

function generateDemoResponse(text) {
  const t = text.toLowerCase();
  if (t.includes("research")) {
    return "Absolutely. I can help structure the research from objectives and methodology through sampling, fieldwork, QC, analysis, and reporting. Tell me the study topic, target audience, geography, and sample size.";
  }
  if (t.includes("business")) {
    return "Let's turn the idea into a practical product. I can help define the problem, target users, value proposition, feature set, revenue model, competitive advantage, MVP, and launch roadmap.";
  }
  if (t.includes("report")) {
    return "I can create a professional report structure with an executive summary, objectives, methodology, findings, recommendations, implementation plan, and management dashboard requirements.";
  }
  if (t.includes("field")) {
    return "For a field operation, I would start with geographic segmentation, interviewer/supervisor deployment, daily targets, training, spot checks, back-checks, rejection rules, escalation, daily synchronization, and a live progress dashboard.";
  }
  return "Thanks — I’m Aurora AI. I can help you research, plan, analyze, write, and turn ideas into practical workflows. Connect your preferred AI provider to replace this demo response engine with live model responses.";
}

export default function App() {
  const [sidebarOpen, setSidebarOpen] = useState(true);
  const [messages, setMessages] = useState([]);
  const [input, setInput] = useState("");
  const [isTyping, setIsTyping] = useState(false);
  const [activeChat, setActiveChat] = useState("New conversation");

  const recent = useMemo(() => messages.filter(m => m.role === "user").slice(-5).reverse(), [messages]);

  const sendMessage = async (preset) => {
    const text = (preset ?? input).trim();
    if (!text || isTyping) return;
    setInput("");
    setMessages(prev => [...prev, { role: "user", content: text }]);
    setActiveChat(text.slice(0, 32) + (text.length > 32 ? "…" : ""));
    setIsTyping(true);

    await new Promise(r => setTimeout(r, 650));
    setMessages(prev => [...prev, { role: "assistant", content: generateDemoResponse(text) }]);
    setIsTyping(false);
  };

  const newChat = () => {
    setMessages([]);
    setInput("");
    setActiveChat("New conversation");
  };

  return (
    <div className="app-shell">
      {sidebarOpen && <div className="mobile-backdrop" onClick={() => setSidebarOpen(false)} />}
      <aside className={`sidebar ${sidebarOpen ? "open" : "closed"}`}>
        <div className="brand">
          <div className="brand-mark"><Sparkles size={17} /></div>
          <span>Aurora</span>
          <span className="brand-ai">AI</span>
          <button className="icon-btn sidebar-close" onClick={() => setSidebarOpen(false)} aria-label="Close sidebar"><PanelLeftClose size={18}/></button>
        </div>

        <button className="new-chat" onClick={newChat}><Plus size={18}/><span>New chat</span><kbd>⌘ K</kbd></button>

        <div className="side-search"><Search size={16}/><span>Search chats</span></div>

        <div className="side-section">
          <div className="section-label">Recent</div>
          {recent.length === 0 ? (
            <div className="empty-history">Your conversations will appear here.</div>
          ) : recent.map((m, i) => (
            <button className="history-item" key={i}><MessageSquare size={15}/><span>{m.content.slice(0, 28)}</span></button>
          ))}
        </div>

        <div className="sidebar-bottom">
          <button className="bottom-item"><Settings size={17}/> Settings</button>
          <div className="profile">
            <div className="avatar">M</div>
            <div><strong>My Workspace</strong><small>Personal</small></div>
            <MoreHorizontal size={17}/>
          </div>
        </div>
      </aside>

      <main className="main">
        <header className="topbar">
          {!sidebarOpen && <button className="icon-btn" onClick={() => setSidebarOpen(true)}><Menu size={20}/></button>}
          <div className="model-select"><div className="model-dot"></div><span>Aurora</span><ChevronDown size={15}/></div>
          <div className="top-actions"><button className="icon-btn"><Search size={18}/></button><button className="icon-btn"><MoreHorizontal size={20}/></button></div>
        </header>

        <section className={`chat-area ${messages.length ? "has-messages" : ""}`}>
          {messages.length === 0 ? (
            <div className="welcome">
              <div className="hero-orb"><Sparkles size={31}/></div>
              <p className="eyebrow">Your intelligent workspace</p>
              <h1>How can I help you today?</h1>
              <p className="subhead">Research ideas, build plans, analyze information, and turn complex work into clear action.</p>

              <div className="prompt-grid">
                {starterPrompts.map(([icon, text]) => (
                  <button className="prompt-card" key={text} onClick={() => sendMessage(text)}>
                    <span className="prompt-icon">{icon}</span><span>{text}</span><ChevronDown className="prompt-arrow" size={16}/>
                  </button>
                ))}
              </div>
            </div>
          ) : (
            <div className="messages">
              {messages.map((m, i) => (
                <div className={`message-row ${m.role}`} key={i}>
                  <div className="message-avatar">{m.role === "assistant" ? <Sparkles size={16}/> : <User size={16}/>}</div>
                  <div className="message-body">
                    <div className="message-name">{m.role === "assistant" ? "Aurora" : "You"}</div>
                    <div className="message-text">{m.content}</div>
                    {m.role === "assistant" && (
                      <div className="message-tools">
                        <button><Copy size={14}/></button><button><ThumbsUp size={14}/></button><button><ThumbsDown size={14}/></button><button><RotateCcw size={14}/></button>
                      </div>
                    )}
                  </div>
                </div>
              ))}
              {isTyping && (
                <div className="message-row assistant">
                  <div className="message-avatar"><Sparkles size={16}/></div>
                  <div className="message-body"><div className="message-name">Aurora</div><div className="typing"><i></i><i></i><i></i></div></div>
                </div>
              )}
            </div>
          )}
        </section>

        <div className="composer-wrap">
          <div className="composer">
            <button className="composer-icon"><Paperclip size={19}/></button>
            <textarea value={input} onChange={e => setInput(e.target.value)} onKeyDown={e => { if(e.key === "Enter" && !e.shiftKey){e.preventDefault();sendMessage();}}} placeholder="Message Aurora…" rows="1" />
            <button className="composer-icon"><Mic size={19}/></button>
            <button className={`send-btn ${input.trim() ? "ready" : ""}`} onClick={() => sendMessage()}><Send size={17}/></button>
          </div>
          <div className="composer-note">Aurora can make mistakes. Verify important information.</div>
        </div>
      </main>
    </div>
  );
}