# Aurora AI Interface

A modern React/Vite AI assistant interface designed for deployment on Vercel.

## Run locally

```bash
npm install
npm run dev
```

## Production build

```bash
npm run build
npm run preview
```

## Deploy

Import the project into Vercel. Vercel supports Vite/React deployment with zero configuration in the normal case.

## AI backend

The current chat uses a local demo response generator so the UI works immediately.

To connect Groq/Llama or another provider, replace `generateDemoResponse()` in `src/App.jsx` with a call to your own secure backend/API route. Do not expose an API key in client-side React code.
